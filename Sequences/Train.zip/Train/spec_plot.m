clc;
clear all;
clf;
x=textread('C:\Users\DELL\Desktop\code\sequences\train\seq2000np.dat','%s');
% x=textread('C:\Users\sunil.sharma\Desktop\EXondetectioninDNA-04-10-19\HMR195\datafile\AF035684_mo_m.dat','%s');
a=char(x);
[r2 c2]=size(a);
c=0;
for i1=1:r2
for j1=1:c2
c=[c a(i1,j1)];
end
end
 L_1=sqrt(-1);
% % %2 prog. for Generating Numeric Code for text-data.......................
D_length=length(c);
for i=1:D_length-1
code=c(i+1);
switch (code)
case {'A','a'}
I6(:,i)=1';
case {'G','g'}
I6(:,i)=2';
case {'C','c'}
I6(:,i)=3';
case {'T','t'}
I6(:,i)=4';
end
end
spectrogram(I6);% finding out the STFT